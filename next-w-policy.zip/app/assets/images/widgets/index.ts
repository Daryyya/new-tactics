import sendSvg from "./send.svg";
import success from './success.svg'

export { sendSvg, success };
