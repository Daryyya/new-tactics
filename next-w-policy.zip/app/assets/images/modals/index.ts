import closeSvg from "./close.svg";

export { closeSvg };
