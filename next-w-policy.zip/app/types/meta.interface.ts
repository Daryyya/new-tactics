export interface IMeta {
  title: string;
  description?: string;
  keywords?: string[];
}
