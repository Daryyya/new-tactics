import sendSvg from "./send.svg";

export { sendSvg };
