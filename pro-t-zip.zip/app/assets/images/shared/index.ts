import whatsappSvg from "./whatsapp.svg";
import mobileBannerSvg from "./banner-img.svg";

export { whatsappSvg, mobileBannerSvg };
