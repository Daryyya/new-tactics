export interface IDiscussParams {
  phone: string;
  name: string;
  message: string;
}
