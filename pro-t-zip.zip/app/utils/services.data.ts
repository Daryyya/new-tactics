export const servicesItems: string[] = [
  "Дизайн",
  "Разработка",
  "ОПТИМИЗАЦИЯ И ЗАЩИТА",
  "ПОДДЕРЖКА",
];
