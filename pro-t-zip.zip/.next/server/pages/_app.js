/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./app/utils/ScrollObserver/ScrollObserver.tsx":
/*!*****************************************************!*\
  !*** ./app/utils/ScrollObserver/ScrollObserver.tsx ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"ScrollContext\": () => (/* binding */ ScrollContext),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst ScrollContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({\n    scrollY: 0\n});\nconst ScrollObserver = ({ children  })=>{\n    const [scrollY, setScrollY] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);\n    const handleScroll = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{\n        setScrollY(window.scrollY);\n    }, []);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        document.addEventListener(\"scroll\", handleScroll, {\n            passive: true\n        });\n        return ()=>document.removeEventListener(\"scroll\", handleScroll);\n    }, [\n        handleScroll\n    ]);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(ScrollContext.Provider, {\n        value: {\n            scrollY\n        },\n        children: children\n    }, void 0, false, {\n        fileName: \"C:\\\\company projects\\\\program-tactics\\\\app\\\\utils\\\\ScrollObserver\\\\ScrollObserver.tsx\",\n        lineNumber: 28,\n        columnNumber: 5\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ScrollObserver);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9hcHAvdXRpbHMvU2Nyb2xsT2JzZXJ2ZXIvU2Nyb2xsT2JzZXJ2ZXIudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFPZTtBQU1SLE1BQU1JLDhCQUFnQkQsb0RBQWFBLENBQWM7SUFDdERFLFNBQVM7QUFDWCxHQUFHO0FBRUgsTUFBTUMsaUJBQXdDLENBQUMsRUFBRUMsU0FBUSxFQUFFLEdBQUs7SUFDOUQsTUFBTSxDQUFDRixTQUFTRyxXQUFXLEdBQUdOLCtDQUFRQSxDQUFDO0lBQ3ZDLE1BQU1PLGVBQWVULGtEQUFXQSxDQUFDLElBQU07UUFDckNRLFdBQVdFLE9BQU9MLE9BQU87SUFDM0IsR0FBRyxFQUFFO0lBQ0xKLGdEQUFTQSxDQUFDLElBQU07UUFDZFUsU0FBU0MsZ0JBQWdCLENBQUMsVUFBVUgsY0FBYztZQUFFSSxTQUFTLElBQUk7UUFBQztRQUNsRSxPQUFPLElBQU1GLFNBQVNHLG1CQUFtQixDQUFDLFVBQVVMO0lBQ3RELEdBQUc7UUFBQ0E7S0FBYTtJQUNqQixxQkFDRSw4REFBQ0wsY0FBY1csUUFBUTtRQUFDQyxPQUFPO1lBQUVYO1FBQVE7a0JBQ3RDRTs7Ozs7O0FBR1A7QUFFQSxpRUFBZUQsY0FBY0EsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3Byb2dyYW0tdGFjdGljcy8uL2FwcC91dGlscy9TY3JvbGxPYnNlcnZlci9TY3JvbGxPYnNlcnZlci50c3g/NTlhNSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gIHVzZUNhbGxiYWNrLFxyXG4gIHVzZUVmZmVjdCxcclxuICB1c2VTdGF0ZSxcclxuICBjcmVhdGVDb250ZXh0LFxyXG4gIEZDLFxyXG4gIFByb3BzV2l0aENoaWxkcmVuLFxyXG59IGZyb20gXCJyZWFjdFwiO1xyXG5cclxuaW50ZXJmYWNlIFNjcm9sbFZhbHVlIHtcclxuICBzY3JvbGxZOiBudW1iZXI7XHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBTY3JvbGxDb250ZXh0ID0gY3JlYXRlQ29udGV4dDxTY3JvbGxWYWx1ZT4oe1xyXG4gIHNjcm9sbFk6IDAsXHJcbn0pO1xyXG5cclxuY29uc3QgU2Nyb2xsT2JzZXJ2ZXI6IEZDPFByb3BzV2l0aENoaWxkcmVuPiA9ICh7IGNoaWxkcmVuIH0pID0+IHtcclxuICBjb25zdCBbc2Nyb2xsWSwgc2V0U2Nyb2xsWV0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBoYW5kbGVTY3JvbGwgPSB1c2VDYWxsYmFjaygoKSA9PiB7XHJcbiAgICBzZXRTY3JvbGxZKHdpbmRvdy5zY3JvbGxZKTtcclxuICB9LCBbXSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJzY3JvbGxcIiwgaGFuZGxlU2Nyb2xsLCB7IHBhc3NpdmU6IHRydWUgfSk7XHJcbiAgICByZXR1cm4gKCkgPT4gZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInNjcm9sbFwiLCBoYW5kbGVTY3JvbGwpO1xyXG4gIH0sIFtoYW5kbGVTY3JvbGxdKTtcclxuICByZXR1cm4gKFxyXG4gICAgPFNjcm9sbENvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3sgc2Nyb2xsWSB9fT5cclxuICAgICAge2NoaWxkcmVufVxyXG4gICAgPC9TY3JvbGxDb250ZXh0LlByb3ZpZGVyPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTY3JvbGxPYnNlcnZlcjtcclxuIl0sIm5hbWVzIjpbInVzZUNhbGxiYWNrIiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJjcmVhdGVDb250ZXh0IiwiU2Nyb2xsQ29udGV4dCIsInNjcm9sbFkiLCJTY3JvbGxPYnNlcnZlciIsImNoaWxkcmVuIiwic2V0U2Nyb2xsWSIsImhhbmRsZVNjcm9sbCIsIndpbmRvdyIsImRvY3VtZW50IiwiYWRkRXZlbnRMaXN0ZW5lciIsInBhc3NpdmUiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiUHJvdmlkZXIiLCJ2YWx1ZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./app/utils/ScrollObserver/ScrollObserver.tsx\n");

/***/ }),

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _assets_styles_globals_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/assets/styles/globals.scss */ \"./app/assets/styles/globals.scss\");\n/* harmony import */ var _assets_styles_globals_scss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_assets_styles_globals_scss__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _utils_ScrollObserver_ScrollObserver__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/utils/ScrollObserver/ScrollObserver */ \"./app/utils/ScrollObserver/ScrollObserver.tsx\");\n\n\n\nfunction App({ Component , pageProps  }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_utils_ScrollObserver_ScrollObserver__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n            ...pageProps\n        }, void 0, false, {\n            fileName: \"C:\\\\company projects\\\\program-tactics\\\\pages\\\\_app.tsx\",\n            lineNumber: 8,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\company projects\\\\program-tactics\\\\pages\\\\_app.tsx\",\n        lineNumber: 7,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQXNDO0FBQzZCO0FBR3BELFNBQVNDLElBQUksRUFBRUMsVUFBUyxFQUFFQyxVQUFTLEVBQVksRUFBRTtJQUM5RCxxQkFDRSw4REFBQ0gsNEVBQWNBO2tCQUNiLDRFQUFDRTtZQUFXLEdBQUdDLFNBQVM7Ozs7Ozs7Ozs7O0FBRzlCLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9wcm9ncmFtLXRhY3RpY3MvLi9wYWdlcy9fYXBwLnRzeD8yZmJlIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIkAvYXNzZXRzL3N0eWxlcy9nbG9iYWxzLnNjc3NcIjtcbmltcG9ydCBTY3JvbGxPYnNlcnZlciBmcm9tIFwiQC91dGlscy9TY3JvbGxPYnNlcnZlci9TY3JvbGxPYnNlcnZlclwiO1xuaW1wb3J0IHR5cGUgeyBBcHBQcm9wcyB9IGZyb20gXCJuZXh0L2FwcFwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHAoeyBDb21wb25lbnQsIHBhZ2VQcm9wcyB9OiBBcHBQcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxTY3JvbGxPYnNlcnZlcj5cbiAgICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cbiAgICA8L1Njcm9sbE9ic2VydmVyPlxuICApO1xufVxuIl0sIm5hbWVzIjpbIlNjcm9sbE9ic2VydmVyIiwiQXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_app.tsx\n");

/***/ }),

/***/ "./app/assets/styles/globals.scss":
/*!****************************************!*\
  !*** ./app/assets/styles/globals.scss ***!
  \****************************************/
/***/ (() => {



/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.tsx"));
module.exports = __webpack_exports__;

})();