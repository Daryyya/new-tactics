exports.id = 16;
exports.ids = [16];
exports.modules = {

/***/ 2742:
/***/ ((module) => {

// Exports
module.exports = {
	"form": "DiscussForm_form__vuSiZ",
	"inputBlock": "DiscussForm_inputBlock__mAPB_",
	"submitBtn": "DiscussForm_submitBtn__xWiqo",
	"error": "DiscussForm_error__gy8k5"
};


/***/ }),

/***/ 4275:
/***/ ((module) => {

// Exports
module.exports = {
	"discuss": "Discuss_discuss__QT9PG",
	"content": "Discuss_content__lgrQt",
	"closeBtn": "Discuss_closeBtn__il9Ya"
};


/***/ }),

/***/ 3874:
/***/ ((module) => {

// Exports
module.exports = {
	"footer": "Footer_footer__jS4Y_",
	"footerBody": "Footer_footerBody__OSeu9",
	"map": "Footer_map__uwkyA",
	"info": "Footer_info__JdbjG",
	"desr": "Footer_desr__wukIf",
	"location": "Footer_location__Ic9kq",
	"locationItem": "Footer_locationItem__hXode",
	"locationLine": "Footer_locationLine__zxejX",
	"block": "Footer_block__wyfT0",
	"social": "Footer_social__Q5LEJ",
	"support": "Footer_support__Yd1fN",
	"supoortItem": "Footer_supoortItem__Gfmf8",
	"copyright": "Footer_copyright__zroTe"
};


/***/ }),

/***/ 1681:
/***/ ((module) => {

// Exports
module.exports = {
	"header": "Header_header__35HgX",
	"headerBody": "Header_headerBody__os8g0",
	"active": "Header_active__LyvNt",
	"menuList": "Header_menuList__1RE0z",
	"actions": "Header_actions__PouXr",
	"phone": "Header_phone__dhjkz",
	"button": "Header_button__dy0Or"
};


/***/ }),

/***/ 8987:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "R3": () => (/* reexport */ award),
  "KV": () => (/* reexport */ benefits_img),
  "BX": () => (/* reexport */ check),
  "e8": () => (/* reexport */ clients_1),
  "IG": () => (/* reexport */ clients_2),
  "Kq": () => (/* reexport */ clients_3),
  "hU": () => (/* reexport */ design),
  "n5": () => (/* reexport */ development),
  "eq": () => (/* reexport */ footer_phone),
  "tx": () => (/* reexport */ integration),
  "Pj": () => (/* reexport */ license),
  "iq": () => (/* reexport */ home_location),
  "jY": () => (/* reexport */ logo),
  "pP": () => (/* reexport */ macbook),
  "rV": () => (/* reexport */ mail),
  "h": () => (/* reexport */ map),
  "aq": () => (/* reexport */ minister),
  "h9": () => (/* reexport */ mission_image),
  "Kf": () => (/* reexport */ mission_icon),
  "Rl": () => (/* reexport */ mission_writing),
  "VC": () => (/* reexport */ mobile),
  "fP": () => (/* reexport */ optimization),
  "CX": () => (/* reexport */ phone),
  "ll": () => (/* reexport */ purpose_img),
  "Hd": () => (/* reexport */ purpose),
  "BS": () => (/* reexport */ review),
  "Kn": () => (/* reexport */ security),
  "kc": () => (/* reexport */ support_img),
  "N5": () => (/* reexport */ support),
  "aX": () => (/* reexport */ team),
  "Tv": () => (/* reexport */ telegram),
  "C6": () => (/* reexport */ vk),
  "wD": () => (/* reexport */ yandex_logo)
});

// UNUSED EXPORTS: firstCase

;// CONCATENATED MODULE: ./app/assets/images/home/logo.svg
/* harmony default export */ const logo = ({"src":"/_next/static/media/logo.edfe01d9.svg","height":97,"width":98});
;// CONCATENATED MODULE: ./app/assets/images/home/macbook.svg
/* harmony default export */ const macbook = ({"src":"/_next/static/media/macbook.007511a8.svg","height":378,"width":512});
;// CONCATENATED MODULE: ./app/assets/images/home/phone.svg
/* harmony default export */ const phone = ({"src":"/_next/static/media/phone.7522e968.svg","height":25,"width":25});
;// CONCATENATED MODULE: ./app/assets/images/home/integration.svg
/* harmony default export */ const integration = ({"src":"/_next/static/media/integration.b70c129f.svg","height":43,"width":37});
;// CONCATENATED MODULE: ./app/assets/images/home/mobile.svg
/* harmony default export */ const mobile = ({"src":"/_next/static/media/mobile.2f8aa083.svg","height":45,"width":33});
;// CONCATENATED MODULE: ./app/assets/images/home/support.svg
/* harmony default export */ const support = ({"src":"/_next/static/media/support.70662232.svg","height":41,"width":41});
;// CONCATENATED MODULE: ./app/assets/images/home/license.svg
/* harmony default export */ const license = ({"src":"/_next/static/media/license.2922091c.svg","height":48,"width":45});
;// CONCATENATED MODULE: ./app/assets/images/home/benefits-img.png
/* harmony default export */ const benefits_img = ({"src":"/_next/static/media/benefits-img.f54eae2a.png","height":325,"width":469,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAA0UlEQVR4nAHGADn/AYR4gn/n7egW9PH2FBIUExMbHhwTFBUVDgsLCx7s6u69AaSdo//X39gABQQFACIiIgAKCgoAMjIyAAcHBgDW09nNAbWus+UVHBca29vb/CEhIQLy8vIADw8P/wgJCAPTz9bbAbavtNoKEQwl2djY/RITEwHs6+sA8/T0/hoaGgTw7PPmAbq0uMy4wLsz7evsAPb29gAhISEAODc4AB0eHQDX09oAAZZ/jLfVz9VC5tzn4xwxIvEmLijuFRkW7RIUEuvj3+XqWH1XE9tF678AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./app/assets/images/home/design.svg
/* harmony default export */ const design = ({"src":"/_next/static/media/design.8a5c15bc.svg","height":506,"width":505});
;// CONCATENATED MODULE: ./app/assets/images/home/case-1.png
/* harmony default export */ const case_1 = ({"src":"/_next/static/media/case-1.d2f40401.png","height":297,"width":525,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAArElEQVR4nA3Auw7BUAAG4P9vkFOkaiCxuQwqGEjdIvEERo9hsEo8BC9kNIjVgIFgkBikhraHtoePq8motbm9duunpxW0UFEkEdNTpIoiGSqbeaBd6fd3WdPg536A1HQ4AXG+XFXRTNpMW027mOA2IwRBQHo+TEhYvaGyCrkuB0AtrJb2Mq7zKz283g4MoWPcaagUgzqXi/n0eDotH4jTEEL9wfVc0ndVuVqb/QAit0Af+VZLYgAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./app/assets/images/home/purpose.svg
/* harmony default export */ const purpose = ({"src":"/_next/static/media/purpose.e1e8f93d.svg","height":68,"width":57});
;// CONCATENATED MODULE: ./app/assets/images/home/purpose-img.png
/* harmony default export */ const purpose_img = ({"src":"/_next/static/media/purpose-img.1e5f3961.png","height":311,"width":423,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAl0lEQVR42gWAsU0DQRBF35+dO4uT3QQJiJwqyJ1RAUVQGTk1kIBICCwHJGvZ551vab9/fTn+fb0fVL0fKjQHgQqzVI3P3O6W+5/ffGZemLYmfWUdKwMQKNW0Hs+NTekaGrGzUUSdTPZoPTHMATCw4V8NuQCDiwSmqkG2OUtiMy40O8qF7bt8enz4iNCbq1awLAEyMPXev28DwkrIzqGW3gAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./app/assets/images/home/check.svg
/* harmony default export */ const check = ({"src":"/_next/static/media/check.e6316069.svg","height":21,"width":22});
;// CONCATENATED MODULE: ./app/assets/images/home/mission-image.png
/* harmony default export */ const mission_image = ({"src":"/_next/static/media/mission-image.84eb405d.png","height":230,"width":233,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAA00lEQVR42gHIADf/AMGuoNOymZJtW8GWgO/LrevGqOzKrurLsgBVeIdZaHPAfmHHhm/MsJ3RuKbItajHtagAXXmHhJSj1ZiFtnRXYXmKd4mVZIKTfo6aAIaJloqQn7+lpbKVknGDlniDlXR+jmV3igBWW2YAIzcoQFCHi5hBSFWOi5eOj5yAhZMAIjVALThEIy89UlpkGjREdm5woJaZjImTACU3QiEvOic1QjlARz5NW1hcYpuKfpaHfgAZKzchMTs0Q00AJTi1rKCQf3t+cmWPgXOknFt7gOd4KQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./app/assets/images/home/mission-icon.svg
/* harmony default export */ const mission_icon = ({"src":"/_next/static/media/mission-icon.fcf9082b.svg","height":57,"width":57});
;// CONCATENATED MODULE: ./app/assets/images/home/mission-writing.png
/* harmony default export */ const mission_writing = ({"src":"/_next/static/media/mission-writing.80ab1d52.png","height":122,"width":496,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAARElEQVR4nA3IQQ5AMBRF0XdbaRgQC2EbrNLEHitR/f06PZz7RbB1IcSCR3OqrL0j0IRnju2esDQLPsklWq2eS1Aauj0/Gn4YM+ni5zYAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":2});
;// CONCATENATED MODULE: ./app/assets/images/home/team.png
/* harmony default export */ const team = ({"src":"/_next/static/media/team.0eee91d2.png","height":103,"width":103,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABBUlEQVR42iXPsUrDQAAG4P8uyaW1xhKNKGYQiiAnaq0QNHZydBPEd/CBRAOuvoMgriHiYCWWZpCCCGLJEmqLTa65nqDfG3wEAG76r1zTtaDIhW8wAxqlkVLqAkBCbvtP3GCVsPvSsR/DB/BNjoPjExi6nqlZ2aaLVS2Qo9SO76/FWXMJDZZCjQbCMkq7pk0DfZ4Wfi5/0FhdZjokNtw1mOaUMZJDUelTU47hOha87V2o4TtMMUbdkKiqHDVSgFZmk2hBK7DTaglFKCbDL1imEnVWooo8IoPvO5703sJuHNvrcym2modIPjKYtpsd+fttgn/8/BSBt+f5jrOC514nurz6/Gv+AgBmY4gWRHb5AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./app/assets/images/home/award.png
/* harmony default export */ const award = ({"src":"/_next/static/media/award.e9e4281f.png","height":468,"width":468,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAtElEQVR42g3OO3LDIBAA0IAWgWLJ1iTpMsnk9GlziRzCjWdcevyTkDDLLgKs9lVP/P/9xqbPuXSd0Y0m71SVFyLY/XyXLOxwnh4YLSzkP942Rkm4Xm7OM4WrAbntP+uuX5YwzB68t127e++/RHlJJdtxTImlyIB+SClWUummCYirRsLCAWY7qhqVUrODtbBpt5WEeZogsqtEJkKHmIU4Hvav2rSmBg4+RdZQF+bT/R6ZaUVZngZlc6eGh5SyAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./app/assets/images/home/clients-1.png
/* harmony default export */ const clients_1 = ({"src":"/_next/static/media/clients-1.6d6ba94d.png","height":65,"width":49,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAQAAABwz0azAAAAYUlEQVR42g3HPQ4BURgAwK9AsVEobEXyEIkTSERD4wwaGifQuKzmHWHZ7E832Z1uwtHSzsbWKfw9zayUvqHXeiskVchuWndTY34mHmpXOVSSwkejCVkpmXvpwsXa3sHCeQDXyEP4zQjDEAAAAABJRU5ErkJggg==","blurWidth":6,"blurHeight":8});
;// CONCATENATED MODULE: ./app/assets/images/home/clients-2.png
/* harmony default export */ const clients_2 = ({"src":"/_next/static/media/clients-2.7f9aaebe.png","height":65,"width":65,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+AWm/6QAAAAAF/Pv7NPHt7wvt7O/+9PP19Pn+/s3x8/X9AWe85gYAAQFHAAEA0/Dp6wTw7vEV5Ojs7fv9/RXu9vfLAWa85kD5+frd8/r74wkFBC7b3OIFJhQO5tbU2ALk+v4jAWO44lf+/Pz9n9XfvlELAkQeHhrord3p/oJIM8RlkqlIAWa75XYCAQGADAH+vycOBA0qGQ4E19jes/gMEhJvs8jRAWe95jn//gCnFggDHxwLBP4iEAb6CgD7p7HT6BS80t2hAf///wBkvedIGgcCYRsKBEIdDQUUAvv4yUlhpnd0QAPGAV3B7ADrGhMBHtziKAz8+S4MAPwdyNbhzBYNCsWkvdH7SeGH3dKfSKUAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./app/assets/images/home/clients-3.png
/* harmony default export */ const clients_3 = ({"src":"/_next/static/media/clients-3.c45010ac.png","height":64,"width":64,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA+klEQVR42iWPy0oDURBE270grtwowZVBdBNX/oAoIpE8Js5LkSEiIii+CDq6D8REQVwYMBnNnWsY9A/60+aWfZNV09XV1ClK4ketqg6nbshjL2C9W2a1X+O01uCR3GhYrbMmgpol9BseBq6L8fYOrGZNNAzkU5Yb/ySPLs/Np/o2+u42t1oaHjElzgGrpSIemi1zetbE71+G907X9Iigg0OmL9fn3nIRqvtqntsdvMUt9I8j81FYxcgalB/yC83j3gnyq609E5Udc71eypOZBfwINCUVISZCe24RF4UVxBubeForTSErdaaBVEmlZuaFrCUuEyY7RZvU/AdM1oVAqfUK5gAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./app/assets/images/home/review.png
/* harmony default export */ const review = ({"src":"/_next/static/media/review.26046793.png","height":104,"width":103,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+AbnEyADs8vQpEQ4OmAoGBTj19PIA9PHxxw4TFWnw29HXAbS7uyrv9PXEFBkfEQkGBgD89/YA7+znAPvk3e8Q+PA8AbjCxsPl4Nc8+gIH+iQpMQYF9vAA2b+v+vMCAgYECQ3EAZ+oqPv38OwE++/qAAcLDwAkHiIA9uLfANP48QD58e78AWZjVvoC49oFMERRAAUOEAARCw4A7ezpAOX+AAD55Nv7AVhURbzTwbtDdIub+gIB/Ab7+/kA5OXl+ggQFwb04tq9AQkZICIxGw7EWVJRGe726wD8AAAAFhoiAPn5+ufIt488AWRVUAA8Qjse2NbXkfT7+T8BBwX/ExITw+/x7W8LBwzhzNF/HQcBPAIAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./app/assets/images/home/yandex-logo.svg
/* harmony default export */ const yandex_logo = ({"src":"/_next/static/media/yandex-logo.574c2963.svg","height":20,"width":49});
;// CONCATENATED MODULE: ./app/assets/images/home/map.svg
/* harmony default export */ const map = ({"src":"/_next/static/media/map.e84f2218.svg","height":289,"width":625});
;// CONCATENATED MODULE: ./app/assets/images/home/location.svg
/* harmony default export */ const home_location = ({"src":"/_next/static/media/location.fbf32dd3.svg","height":24,"width":24});
;// CONCATENATED MODULE: ./app/assets/images/home/footer-phone.svg
/* harmony default export */ const footer_phone = ({"src":"/_next/static/media/footer-phone.92d0f58b.svg","height":24,"width":24});
;// CONCATENATED MODULE: ./app/assets/images/home/mail.svg
/* harmony default export */ const mail = ({"src":"/_next/static/media/mail.8a0d9b0e.svg","height":24,"width":24});
;// CONCATENATED MODULE: ./app/assets/images/home/vk.svg
/* harmony default export */ const vk = ({"src":"/_next/static/media/vk.a90e2350.svg","height":33,"width":33});
;// CONCATENATED MODULE: ./app/assets/images/home/telegram.svg
/* harmony default export */ const telegram = ({"src":"/_next/static/media/telegram.4e7983d1.svg","height":33,"width":33});
;// CONCATENATED MODULE: ./app/assets/images/home/minister.png
/* harmony default export */ const minister = ({"src":"/_next/static/media/minister.409b4336.png","height":95,"width":91,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABBklEQVR42hXG3UrCYBwH4P9ZHdcdRFcTRN1AR11IVHcQYgdBRR/QLIoKdS59l/tobyvCxdxQYekmTcKOnFKb69c8eOChOE6WASxkaBw68njgPsyeWYyTdIkmvvE48l/eeq1GZajt4kvZhudapcg3G5OAV2nYVlRTukKtqMMs304tJqY6ewUXBXx3NEbFeks0xAJ8uRZLpxK06zpCQ4v1koCS2rmn0GY/CpMRCIfobhK8DUJPOP5TZYZBk0U08pSbdy6hf7A3/VgldNcJ/aN8YvEKIk+5JCtI1wxWhl0VwXMneM6foVnLLldgf2KFAMyrhrNzfsfbuQv9d7/wFAtF09G4uwVg7h991sd0adZ0VAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./app/assets/images/home/security.svg
/* harmony default export */ const security = ({"src":"/_next/static/media/security.4bb2c418.svg","height":80,"width":68});
;// CONCATENATED MODULE: ./app/assets/images/home/development.svg
/* harmony default export */ const development = ({"src":"/_next/static/media/development.f48aca34.svg","height":506,"width":506});
;// CONCATENATED MODULE: ./app/assets/images/home/optimization.svg
/* harmony default export */ const optimization = ({"src":"/_next/static/media/optimization.864a8816.svg","height":506,"width":505});
;// CONCATENATED MODULE: ./app/assets/images/home/support-img.png
/* harmony default export */ const support_img = ({"src":"/_next/static/media/support-img.20d32783.png","height":506,"width":587,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAIAAAC6O5sJAAAAuklEQVR42mN4df3fy2t/X1z7+/rG/3e3/r+59f/9nf9vb/1nAOKP9/5/e/T/6pGP03uObltybO388zeOfWK4dfL9immHVszeO7FrT27qju0zKzurVxzZ+pLh0MZbDJquDEF6YaETu5pOzOpe21S999zeNwzn9z4rqZ/pElIa4NR45/SXa8c+zZ989t6Zbwyvbvx7d/P/1cNv1i048f72/3e3/4Od84/h9fV/ILnbQMeAhIAI6LzXN/4DALKVgPwYy82TAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./app/assets/images/home/index.ts





































/***/ }),

/***/ 1448:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "K": () => (/* reexport */ modals_close)
});

;// CONCATENATED MODULE: ./app/assets/images/modals/close.svg
/* harmony default export */ const modals_close = ({"src":"/_next/static/media/close.e1af9713.svg","height":34,"width":34});
;// CONCATENATED MODULE: ./app/assets/images/modals/index.ts




/***/ }),

/***/ 9846:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D": () => (/* binding */ DiscussForm)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _DiscussForm_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2742);
/* harmony import */ var _DiscussForm_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_DiscussForm_module_scss__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5641);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_1__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const DiscussForm = ()=>{
    const { register , handleSubmit , formState: { errors  }  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_1__.useForm)();
    const onSubmit = (data)=>{
        console.log(data);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
        className: (_DiscussForm_module_scss__WEBPACK_IMPORTED_MODULE_2___default().form),
        onSubmit: handleSubmit(onSubmit),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_DiscussForm_module_scss__WEBPACK_IMPORTED_MODULE_2___default().inputBlock),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                        className: errors.phone ? `${(_DiscussForm_module_scss__WEBPACK_IMPORTED_MODULE_2___default().error)}` : "",
                        htmlFor: "phone",
                        children: errors.phone ? errors.phone?.message + "*" : "Контактный телефон"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        ...register("phone", {
                            required: "Телефон обязателен для ввода",
                            pattern: {
                                value: /^(\s*)?(\+)?([- _():=+]?\d[- _():=+]?){10,14}(\s*)?$/,
                                message: "Некорректный номер телефона"
                            }
                        }),
                        type: "tel",
                        id: "phone",
                        name: "phone",
                        placeholder: "Введите здесь",
                        "aria-invalid": errors.phone ? true : false
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_DiscussForm_module_scss__WEBPACK_IMPORTED_MODULE_2___default().inputBlock),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                        className: errors.name ? `${(_DiscussForm_module_scss__WEBPACK_IMPORTED_MODULE_2___default().error)}` : "",
                        htmlFor: "name",
                        children: errors.name ? errors.name?.message + "*" : "Ваше полное имя"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        ...register("name", {
                            required: "Укажите ваше полное имя",
                            pattern: {
                                value: /[A-Za-zА-Яа-яЁё]{3,}/,
                                message: "Некорректное имя"
                            }
                        }),
                        type: "text",
                        id: "name",
                        name: "name",
                        placeholder: "Введите здесь",
                        "aria-invalid": errors.name ? true : false
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_DiscussForm_module_scss__WEBPACK_IMPORTED_MODULE_2___default().inputBlock),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                        className: errors.message ? `${(_DiscussForm_module_scss__WEBPACK_IMPORTED_MODULE_2___default().error)}` : "",
                        htmlFor: "message",
                        children: errors.message ? errors.message?.message + "*" : "Опишите вам проект"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                        ...register("message", {
                            required: "Опишите, пожалуйста, ваш проект",
                            pattern: {
                                value: /[A-Za-zА-Яа-яЁё]{3,}/,
                                message: "Некорректное описание"
                            }
                        }),
                        name: "message",
                        id: "message",
                        placeholder: "Введите здесь",
                        "aria-invalid": errors.message ? true : false
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: (_DiscussForm_module_scss__WEBPACK_IMPORTED_MODULE_2___default().submitBtn),
                disabled: errors.phone || errors.name || errors.message ? true : false,
                type: "submit",
                children: "Отправить"
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9016:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ui_Footer_Footer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9156);
/* harmony import */ var _ui_Header_Header__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9688);
/* harmony import */ var _Meta__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7310);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ui_Header_Header__WEBPACK_IMPORTED_MODULE_2__]);
_ui_Header_Header__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const Layout = ({ title , description , keywords , children  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Meta__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                title: title,
                description: description,
                keywords: keywords
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "wrapper",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_Header_Header__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                        children: children
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_Footer_Footer__WEBPACK_IMPORTED_MODULE_1__/* .Footer */ .$, {})
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7310:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);


const Meta = ({ title , description , keywords  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                children: title
            }),
            description ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "description",
                content: description
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "robots",
                content: "noindex"
            }),
            keywords ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "keywords",
                content: keywords.join(", ")
            }) : null
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Meta);


/***/ }),

/***/ 4247:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _assets_images_modals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1448);
/* harmony import */ var _components_forms_DiscussForm__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9846);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Discuss_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4275);
/* harmony import */ var _Discuss_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Discuss_module_scss__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_forms_DiscussForm__WEBPACK_IMPORTED_MODULE_2__]);
_components_forms_DiscussForm__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const Discuss = ({ setOpenPopup  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_Discuss_module_scss__WEBPACK_IMPORTED_MODULE_4___default().discuss),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_Discuss_module_scss__WEBPACK_IMPORTED_MODULE_4___default().content),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                    onClick: ()=>{
                        setOpenPopup(false);
                    },
                    className: (_Discuss_module_scss__WEBPACK_IMPORTED_MODULE_4___default().closeBtn),
                    src: _assets_images_modals__WEBPACK_IMPORTED_MODULE_1__/* .closeSvg */ .K,
                    alt: "закрыть"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                    children: "Давайте обсудим ваш проект!"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_forms_DiscussForm__WEBPACK_IMPORTED_MODULE_2__/* .DiscussForm */ .D, {})
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Discuss);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9156:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": () => (/* binding */ Footer)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _assets_images_home__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8987);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Footer_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3874);
/* harmony import */ var _Footer_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Footer_module_scss__WEBPACK_IMPORTED_MODULE_4__);





const Footer = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("footer", {
        id: "contacts",
        className: (_Footer_module_scss__WEBPACK_IMPORTED_MODULE_4___default().footer),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_Footer_module_scss__WEBPACK_IMPORTED_MODULE_4___default().footerBody),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_Footer_module_scss__WEBPACK_IMPORTED_MODULE_4___default().info),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                    children: "о компании"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: (_Footer_module_scss__WEBPACK_IMPORTED_MODULE_4___default().desr),
                                    children: "Производитель и поставщик программного обеспечения для бизнеса, предприятий и государственных учреждений. Региональная IT-компания с опытом реализации более 150-и коммерческих проектов."
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_Footer_module_scss__WEBPACK_IMPORTED_MODULE_4___default().location),
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_Footer_module_scss__WEBPACK_IMPORTED_MODULE_4___default().locationItem),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                    children: "Москва"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: (_Footer_module_scss__WEBPACK_IMPORTED_MODULE_4___default().locationLine)
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: (_Footer_module_scss__WEBPACK_IMPORTED_MODULE_4___default().block),
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                            src: _assets_images_home__WEBPACK_IMPORTED_MODULE_1__/* .locationSvg */ .iq,
                                                            alt: "локация"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            children: "г. Москва, б. Энтузиастов 2"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: (_Footer_module_scss__WEBPACK_IMPORTED_MODULE_4___default().block),
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                            src: _assets_images_home__WEBPACK_IMPORTED_MODULE_1__/* .footerPhoneSvg */ .eq,
                                                            alt: "телефон"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            children: "+7 (916) 697 42 27"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: (_Footer_module_scss__WEBPACK_IMPORTED_MODULE_4___default().block),
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                            src: _assets_images_home__WEBPACK_IMPORTED_MODULE_1__/* .mailSvg */ .rV,
                                                            alt: "мэйл"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            children: "connect@protactics.ru"
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_Footer_module_scss__WEBPACK_IMPORTED_MODULE_4___default().locationItem),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                    children: "Оренбург"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: (_Footer_module_scss__WEBPACK_IMPORTED_MODULE_4___default().locationLine)
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: (_Footer_module_scss__WEBPACK_IMPORTED_MODULE_4___default().block),
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                            src: _assets_images_home__WEBPACK_IMPORTED_MODULE_1__/* .locationSvg */ .iq,
                                                            alt: "локация"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            children: "г. Оренбург, ул. Чкалова 3/1"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: (_Footer_module_scss__WEBPACK_IMPORTED_MODULE_4___default().block),
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                            src: _assets_images_home__WEBPACK_IMPORTED_MODULE_1__/* .footerPhoneSvg */ .eq,
                                                            alt: "телефон"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            children: "+7 (916) 697 42 27"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: (_Footer_module_scss__WEBPACK_IMPORTED_MODULE_4___default().block),
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                            src: _assets_images_home__WEBPACK_IMPORTED_MODULE_1__/* .mailSvg */ .rV,
                                                            alt: "мэйл"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            children: "pm@protactics.ru"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_Footer_module_scss__WEBPACK_IMPORTED_MODULE_4___default().social),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                src: _assets_images_home__WEBPACK_IMPORTED_MODULE_1__/* .vkSvg */ .C6,
                                                alt: "Вконтакте"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                src: _assets_images_home__WEBPACK_IMPORTED_MODULE_1__/* .telegramSvg */ .Tv,
                                                alt: "Телеграм"
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_Footer_module_scss__WEBPACK_IMPORTED_MODULE_4___default().map),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                src: _assets_images_home__WEBPACK_IMPORTED_MODULE_1__/* .mapSvg */ .h,
                                alt: "карта"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_Footer_module_scss__WEBPACK_IMPORTED_MODULE_4___default().support),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_Footer_module_scss__WEBPACK_IMPORTED_MODULE_4___default().supoortItem),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    src: _assets_images_home__WEBPACK_IMPORTED_MODULE_1__/* .ministerImg */ .aq,
                                    alt: "министерство"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    children: [
                                        "При поддержке Министерства цифрового развития и связи Оренбургской области",
                                        " "
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_Footer_module_scss__WEBPACK_IMPORTED_MODULE_4___default().supoortItem),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    src: _assets_images_home__WEBPACK_IMPORTED_MODULE_1__/* .securitySvg */ .Kn,
                                    alt: "министерство"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            children: "Надёжный предпринематель"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            href: "/",
                                            children: "По версии Tenchat"
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: (_Footer_module_scss__WEBPACK_IMPORTED_MODULE_4___default().copyright),
                    children: "\xa9 2022. PROT Labs. Все права защищены. ИП Салтанюк Никита Андреевич ."
                })
            ]
        })
    });
};


/***/ }),

/***/ 9688:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _assets_images_home__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8987);
/* harmony import */ var _components_screens_modals_Discuss_Discuss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4247);
/* harmony import */ var _utils_menu_data__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4795);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _Header_module_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1681);
/* harmony import */ var _Header_module_scss__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_Header_module_scss__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_screens_modals_Discuss_Discuss__WEBPACK_IMPORTED_MODULE_2__]);
_components_screens_modals_Discuss_Discuss__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const Header = ()=>{
    const [isOpenMenu, setIsOpenMenu] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    const [isOpenPopup, setIsOpenPopup] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        if (isOpenMenu && window.innerWidth < 992) {
            document.body.style.overflowY = "hidden";
        } else {
            document.body.style.overflowY = "auto";
        }
    }, [
        isOpenMenu
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("header", {
                className: (_Header_module_scss__WEBPACK_IMPORTED_MODULE_7___default().header),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "container",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_Header_module_scss__WEBPACK_IMPORTED_MODULE_7___default().headerBody),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                href: "/",
                                className: (_Header_module_scss__WEBPACK_IMPORTED_MODULE_7___default().logo),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                    src: _assets_images_home__WEBPACK_IMPORTED_MODULE_1__/* .logo */ .jY,
                                    alt: "program tactics"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                                className: isOpenMenu ? `${(_Header_module_scss__WEBPACK_IMPORTED_MODULE_7___default().active)}` : "",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                    className: (_Header_module_scss__WEBPACK_IMPORTED_MODULE_7___default().menuList),
                                    children: _utils_menu_data__WEBPACK_IMPORTED_MODULE_3__/* .menuData.map */ .K.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                scroll: false,
                                                onClick: ()=>setIsOpenMenu(false),
                                                href: item.href,
                                                children: item.text
                                            })
                                        }, item.href))
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_Header_module_scss__WEBPACK_IMPORTED_MODULE_7___default().actions),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        className: (_Header_module_scss__WEBPACK_IMPORTED_MODULE_7___default().phone),
                                        href: "tel:+79166974227",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                src: _assets_images_home__WEBPACK_IMPORTED_MODULE_1__/* .phoneSvg */ .CX,
                                                alt: "phone"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: "+7 (916) 697 42-27"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        onClick: ()=>setIsOpenPopup(true),
                                        className: (_Header_module_scss__WEBPACK_IMPORTED_MODULE_7___default().button),
                                        children: "Обсудить проект"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        onClick: ()=>setIsOpenMenu(!isOpenMenu),
                                        className: isOpenMenu ? "menuBurger active" : "menuBurger",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {})
                                    })
                                ]
                            })
                        ]
                    })
                })
            }),
            isOpenPopup ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_screens_modals_Discuss_Discuss__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                setOpenPopup: setIsOpenPopup
            }) : null
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4795:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K": () => (/* binding */ menuData)
/* harmony export */ });
const menuData = [
    {
        text: "Главная",
        href: "/"
    },
    {
        text: "Услуги",
        href: "/#services"
    },
    {
        text: "Реализованные проекты",
        href: "/#cases"
    },
    {
        text: "Контакты",
        href: "/#contacts"
    }
];


/***/ })

};
;